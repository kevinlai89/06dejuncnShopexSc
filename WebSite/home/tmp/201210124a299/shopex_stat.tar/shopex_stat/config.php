<?php
define('STAT_COMMIT_URL', 'http://b.ecstat.com/api.php');
define('STAT_ACCESS_ADDR', 'http://b.ecstat.com/');
define('STAT_JS_ADDR', 'http://statv.shopex.cn/shopex.js');
