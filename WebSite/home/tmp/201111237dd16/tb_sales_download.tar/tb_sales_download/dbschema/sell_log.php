<?php
    $db['sell_log'] = array (
        'columns' =>
        array (
            'tb_id' =>
            array (
                'type' => 'varchar(20)',
                'required' => true,
                'default'=>'0',
            ),     
        ),
    );
?>