<?php
$setting = array(
	'apikey'=>array('type'=>SET_T_STR,'desc'=>__('如果有自己的一键分享API Key请在这里填写,默认将使用shopex提供的'),'display'=>'false','name'=>'一键分享API Key','default'=>''),
	'appsecret'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('如果有自己的一键分享Secret Key请在这里填写'),'display'=>'false','name'=>'一键分享Secret Key,默认将使用shopex提供的')
);