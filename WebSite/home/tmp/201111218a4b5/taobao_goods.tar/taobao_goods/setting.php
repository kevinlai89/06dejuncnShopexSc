<?php
$setting = array(
	'nick'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('请在此处填写需要同步淘宝商品的店铺对应淘宝用户名。'),'display'=>'false','name'=>'淘宝店用户名')
);