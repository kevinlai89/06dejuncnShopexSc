<?php
$setting = array(
	'appkey'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('在这里输入新浪微博APP Key'),'display'=>'false','name'=>'新浪微博APP Key'),
	'appsecret'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('在这里输入新浪微博Secret'),'display'=>'false','name'=>'新浪微博Secret')
);