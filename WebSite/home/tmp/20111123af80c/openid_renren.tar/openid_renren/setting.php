<?php
$setting = array(
    'appid'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('APP ID 号是指您在人人注册开发者时自动生成的'),'display'=>'false','name'=>'APP ID 号'),
    'loginname'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('应用名称是指您在人人注册开发者是填写的'),'display'=>'false','name'=>'应用名称'),
	'apikey'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('在这里输入人人API Key'),'display'=>'false','name'=>'人人API Key'),
	'appsecret'=>array('type'=>SET_T_STR,'default'=>'','desc'=>__('在这里输入人人Secret'),'display'=>'false','name'=>'人人Secret')
);