<?php
class app_shopex_stat extends app{
    var $ver = 2.0;
    var $name='营销统计工具';
    var $website = 'http://www.shopex.cn';
    var $author = 'shopex';
    var $help = 'http://www.shopex.cn/bbs/thread.php?fid-164.html';



   function ctl_mapper(){
        return array(
          'shop:product:index' => 'lisproduct:get_goodsinfo',
          'admin:member/member:addMemByAdmin' => 'lismember:get_adminaddmen'
       );
    }


    function listener(){
        return array(
            'trading/order:create' =>'listener:get_orderinfo',
            'trading/order:payed'=>'listener:get_payinfo',
            'trading/order:shipping'=>'listener:get_deliveryinfo',
            'member/account:register'=>'listener:get_memberinfo',
            'member/account:login'=>'listener:get_logmember',
            'member/advance:changeadvance'=>'listener:get_money',
            //'member/member:addMemberByAdmin'=>'listener:get_backmember'

        );
    }

    function output_modifiers(){
        return array(
       'shop:*'=>'modifiers:print_footer'
            );

    }


    function getMenu(&$menu){
        $menu['analytics']['items'][]= array_unshift($menu['analytics']['items'],array('type'=>'group','label'=>'营销统计工具','items'=>array(array("type"=>'menu','label'=>__('查看分析报表'),'link'=>'?ctl=plugins/stat_ctl&act=index&redirect=1'))) );
    }

    function install(){
        $status = &$this->system->loadModel('system/status');
        $status->set('site.rsc_rpc','1');
        $this->db->exec("ALTER TABLE `sdb_status` CHANGE `status_value` `status_value` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ");
        parent::install();
        return true;
    }

    function update(){
        $status = &$this->system->loadModel('system/status');
        $this->db->exec("ALTER TABLE `sdb_status` CHANGE `status_value` `status_value` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ");
        $status->set('site.rsc_rpc','1');
        return parent::update();
    }

    function uninstall(){
       
        $certificate = $this->system->loadModel("service/certificate");
         $certi_id = $certificate->getCerti();
           $status_key='ISOPEN'.$certi_id;
             
        $sql = "update sdb_status set status_value='0' where status_key='".$status_key."'" ;
        $this->db->exec($sql);
        return true;
    }

}
